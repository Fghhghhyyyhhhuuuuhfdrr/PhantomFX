# 🎬 MovieBot — Telegram Movie File Search & Sharing Bot

A feature-rich, production-ready Telegram bot for managing and sharing movie/video files from your channels. Users search in groups or private chat, get matching files with **Stream Online** and **Fast Download** buttons, and see IMDb-style details — all automatically.

---

## ✨ Feature Overview

### 👤 User Features
| Feature | Details |
|---|---|
| 🔍 Smart Search | Full-text + fuzzy/regex fallback — typos handled automatically |
| ▶️ Stream Online | In-browser HTML5 player via the bot's own web server |
| ⚡ Fast Download | Direct chunked-download link (no re-upload to any CDN) |
| 🎬 IMDb Details | Auto-fetches title, rating, genre, runtime, plot, poster |
| 📲 Inline Mode | `@YourBot <title>` search from any chat |
| 👑 My Plan | Check free vs premium membership status |
| 🎓 Tutorial Video | Configurable tutorial video via `/start` |

### 🛡 Admin Features
| Feature | Command |
|---|---|
| Index channels | `/index` |
| Connect/disconnect channels | `/addchannel`, `/removechannel` |
| Ban / Unban users | `/ban <id> [reason]`, `/unban <id>` |
| Broadcast to users or groups | `/broadcast users` or `/broadcast groups` |
| Bot statistics | `/stats` |
| View/explain settings | `/settings` |
| Delete CAMRip/PreDVD files | `/deletebad` |
| Add/remove premium | `/addpremium <id> <days>`, `/removepremium <id>` |
| Auto-approve join requests | Handled automatically |

### 🔧 Technical Features
- **MongoDB** storage (Motor async driver) with full-text search index
- **File protection** — `protect_content=True` prevents forwarding/saving
- **Auto-delete** — sent files removed from groups after configurable timer
- **Force subscription** — channel + group supported simultaneously
- **Custom shortlinks** — shareus.in / exe.io / gplinks.in API
- **Logging channel** — all key events logged to a private channel
- **Large file support** — works with the optional self-hosted local Bot API for files >2 GB
- **Quality tag detection** — auto-tags CAMRip, PreDVD, 1080p, 4K, etc.
- **Real-time indexing** — new files posted to connected channels indexed instantly

---

## 📁 Project Structure

```
MovieBot/
├── main.py                     # Entry point
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── render.yaml                 # Render.com deploy config
├── Procfile                    # Heroku
├── app.json                    # Heroku one-click deploy
├── moviebot.service            # systemd unit for VPS
├── .env.example                # Template — copy to .env
│
├── config/
│   └── config.py               # All settings (env var driven)
│
└── bot/
    ├── database/
    │   ├── __init__.py
    │   └── db.py               # MongoDB layer (Motor)
    ├── handlers/
    │   ├── start.py            # /start, /help, /plan, callbacks
    │   ├── search.py           # Group auto-filter + inline search
    │   ├── admin.py            # All admin commands
    │   ├── indexer.py          # Real-time channel indexer
    │   └── groups.py           # Group join/leave tracking
    └── utils/
        ├── stream_server.py    # aiohttp streaming web server
        ├── imdb.py             # cinemagoer IMDb wrapper
        ├── shortlink.py        # Shortlink API wrapper
        └── helpers.py          # Keyboards, broadcast, auto-delete, etc.
```

---

## 🚀 Quick Setup

### Prerequisites
- Python 3.11+
- A Telegram Bot token from [@BotFather](https://t.me/BotFather)
- Telegram API credentials from [my.telegram.org](https://my.telegram.org)
- MongoDB URI — free tier from [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)

### 1. Clone & Configure

```bash
git clone https://github.com/you/MovieBot.git
cd MovieBot
cp .env.example .env
nano .env   # Fill in your values
```

### 2. Prepare your channels

1. Create a Telegram channel (or use an existing one) where you post movie files
2. Add the bot as **Admin** in that channel (at minimum: *Read Messages* permission)
3. Set `FILE_CHANNELS` in `.env` to the channel's ID (use [@userinfobot](https://t.me/userinfobot) or forward a message to get the ID)
4. Optionally create a logging channel, make the bot admin, and set `LOG_CHANNEL`

### 3. BotFather settings

In [@BotFather](https://t.me/BotFather), run:
```
/setinline     → Enable inline mode, set placeholder: "Search movies..."
/setprivacy    → Disable (so bot can read group messages for auto-filter)
/setcommands   → Paste the commands list below
```

**Command list to paste:**
```
start - Start the bot
help - Show help
plan - Check my subscription plan
search - Search for a movie
```

---

## 🐳 Deployment

### Option A — Docker (Recommended for VPS)

```bash
# 1. Fill in your .env
cp .env.example .env && nano .env

# 2. Start everything (bot + MongoDB)
docker compose up -d

# 3. Check logs
docker compose logs -f bot

# 4. Run initial index
docker compose exec bot python -c "
import asyncio
from pyrogram import Client
from config.config import *
from bot.database import db
from bot.utils.helpers import index_channel

async def run():
    await db.connect()
    bot = Client('indexer', api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
    await bot.start()
    for ch in FILE_CHANNELS:
        n, u = await index_channel(bot, ch)
        print(f'Channel {ch}: {n} new, {u} updated')
    await bot.stop()

asyncio.run(run())
"
```

### Option B — Render.com (Free tier available)

1. Fork this repository
2. Go to [render.com](https://render.com) → **New Web Service**
3. Connect your GitHub repo
4. Use the pre-configured `render.yaml`
5. Add your environment variables in the Render dashboard
6. Deploy — Render sets `STREAM_BASE_URL` automatically

> **Note:** Free Render instances spin down after 15 minutes of inactivity. Upgrade to Starter ($7/mo) for always-on.

### Option C — Heroku

```bash
heroku create your-moviebot-name
heroku config:set API_ID=... API_HASH=... BOT_TOKEN=... MONGO_URI=... OWNER_ID=...
heroku config:set STREAM_BASE_URL=https://your-moviebot-name.herokuapp.com
git push heroku main
```

Or use the one-click deploy button (add to your README after forking):

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

### Option D — VPS (Ubuntu/Debian)

```bash
# 1. Install dependencies
sudo apt update && sudo apt install -y python3.11 python3.11-venv

# 2. Clone and set up
git clone https://github.com/you/MovieBot.git /opt/moviebot
cd /opt/moviebot
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Configure
cp .env.example .env && nano .env

# 4. Install and start as a system service
sudo cp moviebot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable moviebot
sudo systemctl start moviebot

# 5. Check status
sudo systemctl status moviebot
sudo journalctl -u moviebot -f
```

---

## 📡 Large File Support (>2 GB)

The standard Telegram Bot API supports files up to **2 GB**. For larger files, you need the **self-hosted local Telegram Bot API server**:

```bash
# Add to your docker-compose.yml (already included, just uncomment)
# Or run standalone:
docker run -d \
  -e TELEGRAM_API_ID=$API_ID \
  -e TELEGRAM_API_HASH=$API_HASH \
  -e TELEGRAM_LOCAL=1 \
  -p 8081:8081 \
  aiogram/telegram-bot-api

# Then in .env:
USE_LOCAL_API=1
LOCAL_API_URL=http://localhost:8081
```

The local API server supports files up to **4 GB** and also removes the 20 MB download limit for `getFile`.

---

## ⚙️ Configuration Reference

All settings live in `.env` (or environment variables on your platform).

| Variable | Default | Description |
|---|---|---|
| `API_ID` | — | **Required.** From my.telegram.org |
| `API_HASH` | — | **Required.** From my.telegram.org |
| `BOT_TOKEN` | — | **Required.** From @BotFather |
| `MONGO_URI` | — | **Required.** MongoDB connection string |
| `OWNER_ID` | — | **Required.** Your Telegram user ID |
| `FILE_CHANNELS` | — | Space-separated channel IDs to index |
| `LOG_CHANNEL` | `0` | Channel ID for activity logs |
| `ADMINS` | `OWNER_ID` | Additional admin user IDs |
| `FORCE_SUB_ENABLED` | `0` | Enable force subscription |
| `FORCE_SUB_CHANNEL` | `0` | Channel users must join |
| `FORCE_SUB_GROUP` | `0` | Group users must join |
| `STREAM_BASE_URL` | `http://localhost:8080` | Public URL of your stream server |
| `PORT` | `8080` | Web server port |
| `USE_LOCAL_API` | `0` | Use self-hosted Bot API (for >2 GB) |
| `LOCAL_API_URL` | — | URL of the local Bot API server |
| `IMDB_ENABLED` | `1` | Show IMDb details in results |
| `AUTO_DELETE_ENABLED` | `1` | Auto-delete files sent to groups |
| `AUTO_DELETE_TIME` | `300` | Seconds before auto-delete |
| `FILE_PROTECT` | `1` | Prevent forwarding/saving of sent files |
| `MAX_RESULTS` | `10` | Max search results per query |
| `SHORTLINK_ENABLED` | `0` | Wrap stream/download URLs in shortlinks |
| `SHORTLINK_API` | — | Shortlink API domain (e.g. `api.shareus.in`) |
| `SHORTLINK_KEY` | — | Your shortlink API key |
| `TUTORIAL_VIDEO` | — | Telegram file_id or URL for tutorial video |
| `START_PIC` | — | Telegraph image URL for /start banner |
| `PREMIUM_ENABLED` | `1` | Enable premium membership system |
| `AUTO_FILTER_BAD` | `0` | Hide CAMRip/PreDVD from search results |

---

## 🗂 MongoDB Collections

| Collection | Purpose |
|---|---|
| `files` | Indexed media (full-text indexed on `file_name`, `caption`) |
| `users` | Registered users, ban status, search count |
| `groups` | Connected groups |
| `settings` | Dynamic settings per scope |
| `premium` | Premium memberships with expiry |

---

## 🔒 Security Notes

- All stream/download links are signed with HMAC-SHA256 using your `BOT_TOKEN` as secret
- Links contain a timestamp and are valid indefinitely (the Telegram `file_path` expires after 1 hour but is re-fetched on each request)
- `protect_content=True` prevents Telegram clients from forwarding or saving sent files
- Never commit your `.env` file — add it to `.gitignore`

---

## 🛠 Troubleshooting

**Bot doesn't index files from channel**
→ Make sure the bot is an admin in the channel with *Read Messages* permission
→ Channel ID must be negative (e.g. `-1001234567890`)
→ Run `/index` manually after adding the bot

**"File not found" on stream/download**
→ The Telegram file path may have expired; it's re-fetched on each request so this should be rare
→ Check that `STREAM_BASE_URL` is correct and the web server is reachable

**Search returns no results**
→ Run `/index` to populate the database
→ Check the MongoDB connection with `/stats`

**Files >2 GB not sending**
→ Enable the local Telegram Bot API server (see Large File Support section)

---

## 📜 License

MIT — feel free to use, modify, and deploy for personal or commercial purposes.
